#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_Security_SecProtocolTypes_symbols(JSContext*);
@protocol OS_sec_trustInstanceExports_<JSExport, NSObjectInstanceExports_>
@end
@protocol OS_sec_trustClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol OS_sec_certificateInstanceExports_<JSExport, NSObjectInstanceExports_>
@end
@protocol OS_sec_certificateClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol OS_sec_identityInstanceExports_<JSExport, NSObjectInstanceExports_>
@end
@protocol OS_sec_identityClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop